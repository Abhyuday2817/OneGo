from django.db.models import Avg, Q, Sum
from django.utils import timezone
from rest_framework import viewsets, filters, generics, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import action
from django_filters import rest_framework as df_filters

from .models import MentorProfile, AvailabilityWindow, MentorAvailability
from .serializers import (
    MentorProfileSerializer,
    AvailabilityWindowSerializer,
    MentorAvailabilitySerializer,
)
from apps.sessions.models import Session  # Used in dashboard

# 🔹 1. Mentor Filtering
class MentorFilter(df_filters.FilterSet):
    rating_min = df_filters.NumberFilter(field_name="rating", lookup_expr="gte")
    language = df_filters.CharFilter(field_name="languages", lookup_expr="icontains")
    specialty = df_filters.NumberFilter(field_name="specialties__id")
    available_at = df_filters.DateTimeFilter(method="filter_availability")

    class Meta:
        model = MentorProfile
        fields = ["rating_min", "language", "specialty"]

    def filter_availability(self, qs, name, value):
        return qs.filter(
            Q(availability_windows__start__lte=value),
            Q(availability_windows__end__gte=value)
        ).distinct()


# 🔹 2. List Mentors + Availability View
class MentorProfileViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = MentorProfile.objects.prefetch_related("specialties", "user").all()
    serializer_class = MentorProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    filterset_class = MentorFilter
    filter_backends = [df_filters.DjangoFilterBackend, filters.OrderingFilter, filters.SearchFilter]
    search_fields = ["user__username", "bio", "expertise"]
    ordering_fields = ["rating", "hourly_rate", "per_minute_rate"]
    ordering = ["-rating"]

    @action(detail=True, methods=["get"], url_path="availability")
    def availability(self, request, pk=None):
        mentor = self.get_object()
        slots = AvailabilityWindow.objects.filter(mentor=mentor).order_by("start")
        serializer = AvailabilityWindowSerializer(slots, many=True)
        return Response(serializer.data)


# 🔹 3. Mentor Dashboard: Earnings, Upcoming Sessions, Avg Rating
class MentorDashboardView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile = getattr(request.user, "mentor_profile", None)
        if not profile:
            return Response({"detail": "User is not a mentor"}, status=status.HTTP_404_NOT_FOUND)

        upcoming = Session.objects.filter(
            mentor=profile,
            start_time__gte=timezone.now(),
            status=Session.STATUS_SCHEDULED
        ).count()

        earnings = Session.objects.filter(
            mentor=profile,
            status=Session.STATUS_COMPLETED,
            verified=True
        ).aggregate(total=Sum("rate_applied"))['total'] or 0

        avg = profile.received_reviews.aggregate(avg=Avg("rating"))['avg'] or 0

        return Response({
            "mentor": MentorProfileSerializer(profile, context={"request": request}).data,
            "upcoming_sessions": upcoming,
            "average_rating": round(avg, 2),
            "total_earnings": round(earnings, 2),
        })


# 🔹 4. GET/PUT - Mentor Profile Self View
class MentorProfileDetailView(generics.RetrieveUpdateAPIView):
    serializer_class = MentorProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ['get', 'put', 'patch']  # ✅ Add this line

    def get_object(self):
        return self.request.user.mentor_profile


# 🔹 5. List Mentors Available Now
class AvailableMentorsView(generics.ListAPIView):
    serializer_class = MentorProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return MentorProfile.objects.filter(
            availability_windows__end__gt=timezone.now()
        ).distinct()


# 🔹 6. CRUD Manual Time Slots (datetime-based)
class AvailabilityWindowViewSet(viewsets.ModelViewSet):
    serializer_class = AvailabilityWindowSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if getattr(self, 'swagger_fake_view', False):
            return AvailabilityWindow.objects.none()

        user = self.request.user
        if not hasattr(user, 'mentor_profile'):
            return AvailabilityWindow.objects.none()

        return AvailabilityWindow.objects.filter(mentor=user.mentor_profile).order_by("start")

    def perform_create(self, serializer):
        serializer.save(mentor=self.request.user.mentor_profile)


# 🔹 7. CRUD Weekly Availability (recurring weekly slots)
class MentorAvailabilityViewSet(viewsets.ModelViewSet):
    serializer_class = MentorAvailabilitySerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if getattr(self, 'swagger_fake_view', False):
            return MentorAvailability.objects.none()

        user = self.request.user
        if not hasattr(user, 'mentor_profile'):
            return MentorAvailability.objects.none()

        return MentorAvailability.objects.filter(mentor=user.mentor_profile).order_by("day", "start_time")

    def perform_create(self, serializer):
        serializer.save(mentor=self.request.user.mentor_profile)
