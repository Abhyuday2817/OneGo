from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from apps.mentors.models import MentorProfile, AvailabilityWindow, MentorAvailability
from apps.appointments.models import Appointment
from datetime import datetime, timedelta
from django.utils.timezone import make_aware
from apps.categories.models import Category
from django.urls import reverse
from rest_framework import status

User = get_user_model()

class MentorProfileTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="mentor1", password="Mentor@123")
        self.student_user = User.objects.create_user(username="student1", password="Student@123")
        self.category = Category.objects.create(name="Technology")
        self.mentor = MentorProfile.objects.create(
            user=self.user,
            bio="Experienced mentor",
            hourly_rate=500,
            per_minute_rate=10,
            expertise="Python",
            rating=4.8,
            num_reviews=12,
            education="B.Tech in CS",
            experience="5 years",
            languages="en,hi"
        )
        self.mentor.specialties.add(self.category)

        self.availability = AvailabilityWindow.objects.create(
            mentor=self.mentor,
            start=make_aware(datetime.now() + timedelta(hours=1)),
            end=make_aware(datetime.now() + timedelta(hours=3))
        )

        self.weekly_avail = MentorAvailability.objects.create(
            mentor=self.mentor,
            day="mon",
            start_time="09:00:00",
            end_time="11:00:00",
            timezone="Asia/Kolkata"
        )

        self.client.force_authenticate(user=self.user)

    def test_mentor_profile_str(self):
        self.assertEqual(str(self.mentor), f"{self.user.username} (⭐{self.mentor.rating:.1f})")

    def test_mentor_dashboard(self):
        url = reverse("mentor-dashboard")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertIn("mentor", response.data)
        self.assertIn("total_earnings", response.data)

    def test_mentor_me_view(self):
        url = reverse("mentor-profile-self")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["user"]["id"], self.user.id)

    def test_update_mentor_profile(self):
        url = reverse("mentor-profile-self")
        data = {"bio": "Updated bio", "specialty_ids": [self.category.id]}
        response = self.client.patch(url, data, format="json")
        self.assertEqual(response.status_code, 200)
        self.mentor.refresh_from_db()
        self.assertEqual(self.mentor.bio, "Updated bio")

    def test_mentor_availability_endpoint(self):
        url = reverse("availability-window-list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.data), 1)

    def test_available_mentors_list(self):
        url = reverse("mentor-available-list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.data), 1)

    def test_recurring_weekly_availability_create(self):
        url = reverse("weekly-availability-list")
        data = {
            "day": "tue",
            "start_time": "10:00:00",
            "end_time": "12:00:00",
            "timezone": "Asia/Kolkata"
        }
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data["day"], "tue")

    def test_get_weekly_availability(self):
        url = reverse("weekly-availability-list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.data), 1)

    def test_create_availability_window(self):
        url = reverse("availability-window-list")
        start = make_aware(datetime.now() + timedelta(days=1, hours=2))
        end = start + timedelta(hours=1)
        data = {"start": start.isoformat(), "end": end.isoformat()}
        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data["mentor"], self.mentor.id)

    def test_unauthenticated_access_denied(self):
        self.client.logout()
        url = reverse("mentor-dashboard")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_invalid_user_mentor_dashboard(self):
        new_user = User.objects.create_user(username="student2", password="test456")
        self.client.force_authenticate(user=new_user)
        url = reverse("mentor-dashboard")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 404)
    
    def test_partial_update_mentor_profile(self):
        url = reverse("mentor-profile-self")
        data = {"bio": "Patched bio"}
        response = self.client.patch(url, data, format="json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["bio"], "Patched bio")
