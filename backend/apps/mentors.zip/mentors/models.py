from django.db import models
from django.conf import settings
from django.utils import timezone
from django.apps import apps
from apps.categories.models import Category


class MentorProfileQuerySet(models.QuerySet):
    def top_rated(self, min_rating=4.0):
        return self.filter(rating__gte=min_rating).order_by('-rating', '-num_reviews')

    def available_at(self, dt):
        return self.filter(
            availability_windows__start__lte=dt,
            availability_windows__end__gte=dt,
        ).distinct()


class MentorProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='mentor_profile')
    bio = models.TextField(blank=True)
    specialties = models.ManyToManyField(Category, related_name='mentors')
    hourly_rate = models.DecimalField(max_digits=8, decimal_places=2)
    per_minute_rate = models.DecimalField(max_digits=8, decimal_places=2)
    rating = models.FloatField(default=0)
    num_reviews = models.PositiveIntegerField(default=0)
    certifications = models.TextField(blank=True)
    languages = models.CharField(max_length=200, blank=True, help_text='Comma-separated ISO language codes (e.g. en, hi, fr)')
    expertise = models.CharField(max_length=255, default='General')
    linkedin_url = models.URLField(blank=True)
    youtube_url = models.URLField(blank=True)
    country = models.CharField(max_length=100, blank=True)
    availability_slots = models.CharField(max_length=255, default="9AM-5PM")
    profile_photo = models.ImageField(upload_to='mentors/photos/', blank=True, null=True)
    social_linkedin = models.URLField(blank=True, null=True)
    social_youtube = models.URLField(blank=True, null=True)
    education = models.TextField(blank=True)
    experience = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = MentorProfileQuerySet.as_manager()

    class Meta:
        ordering = ['-rating', 'user__username']

    def __str__(self):
        return f'{self.user.username} (⭐{self.rating:.1f})'

    def get_upcoming_sessions(self):
        Session = apps.get_model('sessions', 'Session')
        return Session.objects.filter(mentor_id=self.id, start_time__gte=timezone.now())

    def total_earnings(self):
        Session = apps.get_model('sessions', 'Session')
        qs = Session.objects.filter(mentor_id=self.id, status='Completed', verified=True)
        return qs.aggregate(models.Sum('rate_applied'))['rate_applied__sum'] or 0

    def total_students_taught(self):
        Session = apps.get_model('sessions', 'Session')
        return Session.objects.filter(mentor_id=self.id).values('student').distinct().count()

    def is_available(self, start, end):
        Session = apps.get_model('sessions', 'Session')
        for win in self.availability_windows.all():
            if win.start <= start and win.end >= end:
                conflict = Session.objects.filter(
                    mentor_id=self.id,
                    start_time__lt=end,
                    end_time__gt=start,
                    status__in=['Scheduled', 'Completed'],
                ).exists()
                return not conflict
        return False

    def weekly_availability_today(self):
        today = timezone.now().strftime('%a').lower()
        return self.weekly_availability.filter(day=today, is_available=True)

    def average_session_duration(self):
        Session = apps.get_model('sessions', 'Session')
        sessions = Session.objects.filter(mentor_id=self.id, status='Completed')
        return sessions.aggregate(avg=models.Avg(models.F('end_time') - models.F('start_time')))['avg']


class AvailabilityWindow(models.Model):
    mentor = models.ForeignKey(MentorProfile, related_name='availability_windows', on_delete=models.CASCADE)
    start = models.DateTimeField()
    end = models.DateTimeField()

    class Meta:
        ordering = ['start']

    def __str__(self):
        return f"{self.mentor.user.username}: {self.start} → {self.end}"


class MentorAvailability(models.Model):
    WEEKDAYS = [
        ('mon', 'Monday'),
        ('tue', 'Tuesday'),
        ('wed', 'Wednesday'),
        ('thu', 'Thursday'),
        ('fri', 'Friday'),
        ('sat', 'Saturday'),
        ('sun', 'Sunday'),
    ]

    mentor = models.ForeignKey(MentorProfile, related_name='weekly_availability', on_delete=models.CASCADE)
    day = models.CharField(max_length=3, choices=WEEKDAYS)
    start_time = models.TimeField()
    end_time = models.TimeField()
    timezone = models.CharField(max_length=100, default='Asia/Kolkata')
    is_available = models.BooleanField(default=True)

    class Meta:
        unique_together = ('mentor', 'day', 'start_time', 'end_time')
        ordering = ['mentor', 'day', 'start_time']

    def __str__(self):
        return f"{self.get_day_display()} {self.start_time}–{self.end_time} ({self.mentor.user.username})"

    def overlaps(self, check_time):
        local_time = check_time.astimezone(timezone.get_current_timezone()).time()
        return self.is_available and self.start_time <= local_time <= self.end_time
