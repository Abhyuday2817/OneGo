from rest_framework import serializers
from apps.mentors.models import MentorProfile, AvailabilityWindow, MentorAvailability
from apps.users.serializers import UserSerializer
from apps.categories.serializers import CategorySerializer


# 🔹 Slot-based Availability (datetime-based)
class AvailabilityWindowSerializer(serializers.ModelSerializer):
    class Meta:
        model = AvailabilityWindow
        fields = ['id', 'start', 'end']
        read_only_fields = ['id']


# 🔹 Weekly Availability Serializer
class MentorAvailabilitySerializer(serializers.ModelSerializer):
    day_display = serializers.CharField(source='get_day_display', read_only=True)

    class Meta:
        model = MentorAvailability
        fields = [
            'id', 'mentor', 'day', 'day_display', 'start_time', 'end_time',
            'timezone', 'is_available'
        ]
        read_only_fields = ['id', 'day_display']
        extra_kwargs = {
            'mentor': {'required': False}
        }


# 🔹 Mentor Profile Serializer
class MentorProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    specialties = CategorySerializer(many=True, read_only=True)

    specialty_ids = serializers.PrimaryKeyRelatedField(
        many=True,
        write_only=True,
        queryset=CategorySerializer.Meta.model.objects.all(),
        source='specialties'
    )

    availability_windows = AvailabilityWindowSerializer(many=True, read_only=True)
    weekly_availability = MentorAvailabilitySerializer(many=True, read_only=True)

    upcoming_session_count = serializers.SerializerMethodField()
    total_earnings = serializers.SerializerMethodField()
    average_session_duration = serializers.SerializerMethodField()
    total_students = serializers.SerializerMethodField()

    class Meta:
        model = MentorProfile
        fields = [
            'id', 'user', 'bio', 'expertise', 'specialties', 'specialty_ids',
            'hourly_rate', 'per_minute_rate',
            'rating', 'num_reviews',
            'certifications', 'languages', 'country', 'profile_photo',
            'linkedin_url', 'youtube_url',
            'availability_windows', 'weekly_availability',
            'upcoming_session_count', 'total_earnings', 'average_session_duration', 'total_students',
            'created_at', 'updated_at',
        ]
        read_only_fields = [
            'id', 'user', 'rating', 'num_reviews',
            'upcoming_session_count', 'total_earnings', 'average_session_duration', 'total_students',
            'created_at', 'updated_at',
            'availability_windows', 'weekly_availability',
        ]

    def get_upcoming_session_count(self, obj):
        try:
            return obj.get_upcoming_sessions().count()
        except Exception:
            return 0

    def get_total_earnings(self, obj):
        try:
            return obj.total_earnings()
        except Exception:
            return 0

    def get_average_session_duration(self, obj):
        try:
            from apps.sessions.models import Session
            sessions = Session.objects.filter(mentor=obj, status=Session.STATUS_COMPLETED)
            if not sessions.exists():
                return 0
            total_duration = sum(
                [(s.end_time - s.start_time).total_seconds() for s in sessions if s.end_time and s.start_time],
                0
            )
            avg_minutes = total_duration / 60 / sessions.count()
            return round(avg_minutes, 2)
        except Exception:
            return 0

    def get_total_students(self, obj):
        try:
            from apps.sessions.models import Session
            return Session.objects.filter(mentor=obj).values('student').distinct().count()
        except Exception:
            return 0
