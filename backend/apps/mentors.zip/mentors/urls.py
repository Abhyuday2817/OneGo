from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    MentorProfileViewSet,
    MentorDashboardView,
    MentorProfileDetailView,
    AvailableMentorsView,
    AvailabilityWindowViewSet,
    MentorAvailabilityViewSet,
)

router = DefaultRouter()
router.register(r'mentors', MentorProfileViewSet, basename='mentor')
router.register(r'availability-windows', AvailabilityWindowViewSet, basename='availability-window')
router.register(r'weekly-availability', MentorAvailabilityViewSet, basename='weekly-availability')

urlpatterns = [
    path('', include(router.urls)),
    path('mentors/me/', MentorProfileDetailView.as_view(), name='mentor-me'),
    path('mentors/available/', AvailableMentorsView.as_view(), name='mentor-available'),
    path('mentors/dashboard/', MentorDashboardView.as_view(), name='mentor-dashboard'),
]
